ALUNO: JOAO PEDRO ASSUNÇÃO COUTINHO
MATRÍCULA: 180019813

EXTRAS DA PARTE 1 DO TRABALHO:
    -Cores nos 'X' e nos 'F';
    -Implementação do botão SAIR;

INSTRUÇÕES DE COMPILAÇÃO:
    -Não são necessárias diretivas de compilação específicas;
    -Compilar normalmente com gcc -ansi -Wall -o <Saída> <Arquivo>.c;
___________________________________________________________________________

